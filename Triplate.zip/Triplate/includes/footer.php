
<style>

/* Button used to open the chat form - fixed at the bottom of the page */
.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:40px;
	right:40px;
  font-size:25px;
	background-color:#991416;
	color:#FFF;
	border-radius:50px;
	text-align:center;
	box-shadow: 2px 2px 3px #999;
}

.my-float{
	margin-top:22px;
}

/* The popup chat - hidden by default */
.chat-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width textarea */
.form-container textarea {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
  resize: none;
  min-height: 200px;
}

/* When the textarea gets focus, do something */
.form-container textarea:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/send button */
.form-container .btnn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btnn:hover, .open-button:hover {
  opacity: 1;
}

</style>


<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Follow us: </h2>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="https://twitter.com/TriplateS"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href=" "><span class="icon-linkedin"></span></a></li>
                <li class="ftco-animate"><a href=""><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href=" "><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Business Working Hours: </h2>
              <p>Monday:   8:00 to 17:00</p>
              <p>Tuesday:  8:00 to 17:00</p>
              <p>Wedesday: 8:00 to 17:00</p>
              <p>Thursday: 8:00 to 17:00</p>
              <p>Friday:   8:00 to 17:00</p>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Get in Touch With Us</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text"><p>143 Borrowdale Road</p>
                  <p>Gunhill</p>
                  <p>Harare, Zimbabwe</p>   
                         </span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text"><p>+263 719 541 091<p> <p>+263 242 252 381</p></span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">sales@triplatesecurity.co.zw</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        </div>    
        <div class="row">
          <div class="col-md-12 text-center">

            <p>
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Website made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://rrce.org" target="_blank">Rodney</a>
  </p>
          </div>
        </div>
        
			
      </div>
    </footer>
    
   

    